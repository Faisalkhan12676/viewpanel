import { combineReducers } from "redux";
import loggedinReducer from "./LoggedinReducer";
import NotifyReducer from "./NotifyReducer";


export const Root = combineReducers({
    loggedinReducer: loggedinReducer,
    NotifyReducer: NotifyReducer,
})

