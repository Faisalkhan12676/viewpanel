
const isNotifystate = {
    notify: false,
}

const NotifyReducer = (state = isNotifystate, action) => {
    switch (action.type) {
        case 'NOTIFY':
            return {
                ...state,
                notify: true,
            }

        case 'NOTIFY_OFF':
            return {
                ...state,
                notify: false,
            }
        default:
            return state;
    }
}

export default NotifyReducer;