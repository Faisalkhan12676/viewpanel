
const isloggedin = {
    loggedin: false,
}

const loggedinReducer = (state = isloggedin, action) => {
    switch (action.type) {
        case 'LOGIN':
            return {
                ...state,
                loggedin: true,
            }

        case 'LOGOUT':
            return {
                ...state,
                loggedin: false,
            }
        default:
            return state;
    }
}

export default loggedinReducer;