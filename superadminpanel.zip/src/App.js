import React, { useEffect, useState } from "react";
import { Routes, Route, Navigate, Switch, useNavigate } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Redirect from "react-router-dom";
import NavigationTab from "./pages/NavigationTab";
import { useSelector } from "react-redux";

const App = () => {
  const [token, setToken] = useState("");
  const [role, setRole] = useState("");
  const auth = useSelector((state) => state.loggedinReducer.loggedin);
  useEffect(() => {
    //get token and role from session
    const token = sessionStorage.getItem("token");
    const role = sessionStorage.getItem("role");
    setToken(token);
    setRole(role);
  }, [auth]);

  // console.log(auth);
  // console.log(token);
  // console.log(role);
  return (
    <>
      <Routes>
        {token === null && role === null ? (
          <Route path="/login" element={<Login />} />
        ) : (
          <>
            {role === "SuperAdmin" ? (
              <>
                <Route path="/dashboard/*" element={<NavigationTab />} />
              </>
            ) : (
              <>
                <Route path="/login" element={<Login />} />
              </>
            )}
          </>
        )}

        <Route
          path="*"
          element={
            <Navigate
              
              to={
                token !== null && role === "SuperAdmin" ? "/dashboard/home" : "/login"
              }
            />
          }
        />
      </Routes>
    </>
  );
};

export default App;
