export const color = {
    primary: '#2A9381',
    divider: '#ced4da',
    black: '#000',
    card:"#0467B1",
    light:"#F7F7F7",
}