import React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";
import { Formik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASE_URL } from "../../config";
import { useNavigate } from "react-router-dom";

const ScheduleExam = () => {
    const navigate = useNavigate();
  return (
    <div className="cardarea">
      <div className="cardinput">
        <h1
          style={{
            textAlign: "center",
          }}
        >
          Schedule Exam
        </h1>
        <Formik
          initialValues={{
            exam: "",
            time: "",
            date: "",
          }}
          validationSchema={Yup.object({
            exam: Yup.string().required("Exam is required"),
            time:Yup.string().required("Time is Required"),
            date:Yup.string().required("Date is Required")
          })}
          onSubmit={(values) => {
            console.log(values);
            navigate("/dashboard/thankyou")
          }}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
          }) => (
            <>
              <TextField
                id="exam"
                label="Exam"
                variant="outlined"
                margin="normal"
                required
                fullWidth
                helperText={touched.exam && errors.exam}
                error={touched.exam && errors.exam}
                onChange={handleChange("exam")}
                onBlur={handleBlur("exam")}
                value={values.exam}
              />
              <div
                style={{
                  display: "flex",
                  marginTop: 20,
                }}
              >
                <TextField
                  style={{
                    marginLeft: 10,
                    marginRight: 10,
                  }}
                  id="time"
                  label="Time"
                  type="time"
                  defaultValue="07:30"
                  value={values.time}
                  onChange={handleChange("time")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                  helperText={touched.time && errors.time}
                  error={touched.time && errors.time}
                  inputProps={{
                    step: 300, // 5 min
                  }}
                  sx={{ width: 150 }}
                />

                <TextField
                  style={{
                    marginLeft: 10,
                    marginRight: 10,
                  }}
                  id="date"
                  label="Date"
                  type="date"
                  defaultValue="2017-05-24"
                  onChange={handleChange("date")}
                  value={values.date}
                  helperText={touched.date && errors.date}
                  error={touched.date && errors.date}
                  sx={{ width: 220 }}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </div>
              <div
              style={{
                display: "flex",
                  marginTop: 20,
                  justifyContent:'center'
              }}
              >
                <Button variant="contained" onClick={handleSubmit}>Schedule Exam</Button>
              </div>
              
            </>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default ScheduleExam;
