import React, { useEffect, useState } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Button } from "@mui/material";
import axios from "axios";
import { BASE_URL } from "../../config";
import { Link, useNavigate } from "react-router-dom";
import { TailSpin } from "react-loader-spinner";
import { color } from "../../components/colors";

const ExamTable = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isloading2, setIsloading2] = useState(false);
  const navigate = useNavigate();
  const getExams = () => {};

  useEffect(() => {
    getExams();
  }, []);
  return (
    <>
      {isloading2 ? (
        <>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "80vh",
            }}
          >
            <TailSpin color={color.primary} />
          </div>
        </>
      ) : (
        <>
          <Button
            variant="contained"
            style={{
              margin: 10,
            }}
            onClick={() => navigate("/dashboard/scheduleexam")}
          >
            Schedule Exam
          </Button>

          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>NAME</TableCell>
                  <TableCell>ACTIONS</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                
              </TableBody>
            </Table>
          </TableContainer>
        </>
      )}
    </>
  );
};

export default ExamTable;
