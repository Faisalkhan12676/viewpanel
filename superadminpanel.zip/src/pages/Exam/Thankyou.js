import { Button } from "@mui/material";
// import { color } from "@mui/system";
import React from "react";
import { useNavigate } from "react-router-dom";
import { color } from "../../components/colors";


const Thankyou = () => {
    const navigate = useNavigate()
  return (
    <div className="cardarea">
      <div className="cardinput">
        <h1>
          <span
            style={{
              color: color.primary,
            }}
          >
            Thank you !
          </span>
          Exam Schedule Successfully ✔️
        </h1>

        <div
          style={{
            display: "flex",
            justifyContent: "center",
          }}
        >
          <Button onClick={()=>{
            navigate("/dashboard/examtable")
          }} style={{ color: color.primary }}>Go To Exam Records</Button>
        </div>
      </div>
    </div>
  );
};

export default Thankyou;
