import React, { useEffect, useState } from "react";
import { styled, useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import MuiDrawer from "@mui/material/Drawer";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import CssBaseline from "@mui/material/CssBaseline";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import HomeIcon from "@mui/icons-material/Home";
import DashboardIcon from "@mui/icons-material/Dashboard";
import { Routes, Route, Link, Navigate } from "react-router-dom";
import Home from "./Home";
import { color } from "../components/colors";
import LogoutIcon from "@mui/icons-material/Logout";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import MapsHomeWorkIcon from "@mui/icons-material/MapsHomeWork";
import LocationCityIcon from "@mui/icons-material/LocationCity";
import CollectionsBookmarkIcon from "@mui/icons-material/CollectionsBookmark";
import PersonIcon from "@mui/icons-material/Person";
import ViewCarouselIcon from "@mui/icons-material/ViewCarousel";
import NotificationsIcon from "@mui/icons-material/Notifications";
import HistoryEduIcon from "@mui/icons-material/HistoryEdu";

//ALL COMPONENETS
//AREA
import Area from "./Area/Area";
import AddArea from "./Area/AddArea";
import EditArea from "./Area/EditArea";
import City from "./City/City";
import AddCity from "./City/AddCity";
import EditCity from "./City/EditCity";
import AddCourse from "./Course/AddCourse";
import Course from "./Course/Course";
import EditCourse from "./Course/EditCourse";
import User from "./User/User";
import Banner from "./Banner/Banner";
import AddBanner from "./Banner/AddBanner";
import EditBanner from "./Banner/EditBanner";
import AddUser from "./User/AddUser";
import Notification from "./Notification/Notification";
import PreviousNotification from "./Notification/PreviousNotification";
import DetailNotification from "./Notification/DetailNotification";
import AdmitCard from "./AdmitCard/AdmitCard";
import BadgeIcon from "@mui/icons-material/Badge";
import ScheduleExam from "./Exam/ScheduleExam";
import Thankyou from "./Exam/Thankyou";
import ExamTable from "./Exam/ExamTable";

//

const drawerWidth = 240;

const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(9)} + 1px)`,
  },
});

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-end",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
}));

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": openedMixin(theme),
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": closedMixin(theme),
  }),
}));

const NavigationTab = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const auth = useSelector((state) => state.loggedinReducer.loggedin);
  // const notified = useSelector((state) => state.NotifyReducer.notify);

  // console.log(auth);
  useEffect(() => {
    if (
      sessionStorage.getItem("token") === null &&
      sessionStorage.getItem("role") === null
    ) {
      navigate("/login");
    }
  }, [auth]);

  const theme = useTheme();
  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  return (
    <>
      <Box sx={{ display: "flex" }}>
        <CssBaseline />
        <AppBar
          position="fixed"
          open={open}
          style={{ backgroundColor: color.primary }}
        >
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              onClick={handleDrawerOpen}
              edge="start"
              sx={{
                marginRight: "36px",
                ...(open && { display: "none" }),
              }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" color={"#eee"} noWrap component="div">
              Super Admin Panel
            </Typography>
          </Toolbar>
        </AppBar>
        <Drawer variant="permanent" open={open}>
          <DrawerHeader
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <h4>Bano Qabil</h4>
            <IconButton onClick={handleDrawerClose}>
              {theme.direction === "rtl" ? (
                <ChevronRightIcon />
              ) : (
                <ChevronLeftIcon />
              )}
            </IconButton>
          </DrawerHeader>
          <Divider />
          <List>
            <Link to="/dashboard/home">
              <ListItem button>
                <ListItemIcon>
                  <DashboardIcon />
                </ListItemIcon>
                <ListItemText primary={"Dasboard"} />
              </ListItem>
            </Link>

            <Link to="/dashboard/user">
              <ListItem button>
                <ListItemIcon>
                  <PersonIcon />
                </ListItemIcon>
                <ListItemText primary={"User"} />
              </ListItem>
            </Link>

            <Link to="/dashboard/area">
              <ListItem button>
                <ListItemIcon>
                  <MapsHomeWorkIcon />
                </ListItemIcon>
                <ListItemText primary={"Area"} />
              </ListItem>
            </Link>

            <Link to="/dashboard/city">
              <ListItem button>
                <ListItemIcon>
                  <LocationCityIcon />
                </ListItemIcon>
                <ListItemText primary={"City"} />
              </ListItem>
            </Link>

            <Link to="/dashboard/course">
              <ListItem button>
                <ListItemIcon>
                  <CollectionsBookmarkIcon />
                </ListItemIcon>
                <ListItemText primary={"Course"} />
              </ListItem>
            </Link>

            <Link to="/dashboard/banner">
              <ListItem button>
                <ListItemIcon>
                  <ViewCarouselIcon />
                </ListItemIcon>
                <ListItemText primary={"Banner"} />
              </ListItem>
            </Link>

            <Link to="/dashboard/notification">
              <ListItem button>
                <ListItemIcon>
                  <NotificationsIcon />
                </ListItemIcon>
                <ListItemText primary={"Notification"} />
              </ListItem>
            </Link>
            <Link to="/dashboard/admitcard">
              <ListItem button>
                <ListItemIcon>
                  <BadgeIcon />
                </ListItemIcon>
                <ListItemText primary={"Admit Card"} />
              </ListItem>
            </Link>

            <Link to="/dashboard/scheduleexam">
              <ListItem button>
                <ListItemIcon>
                  <HistoryEduIcon />
                </ListItemIcon>
                <ListItemText primary={"Schedule Exam"} />
              </ListItem>
            </Link>

            <ListItem
              button
              onClick={() => {
                dispatch({ type: "LOGOUT" });
                sessionStorage.clear();
                window.location.reload(true);
                // if (
                //   sessionStorage.getItem("token") === null &&
                //   sessionStorage.getItem("role") === null
                // ) {
                //   navigate("/login");
                // }
              }}
            >
              <ListItemIcon>
                <LogoutIcon />
              </ListItemIcon>
              <ListItemText primary={"Logout"} />
            </ListItem>
          </List>
        </Drawer>

        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
          <DrawerHeader />
          {/* CONTENT GOES HERE */}

          <Routes>
            {/* HOME ROUTE */}
            <Route path="/home" element={<Home />} />
            {/* AREA ROUTE */}
            <Route path="/area" element={<Area />} />
            <Route path="/area/add" element={<AddArea />} />
            <Route path="/area/edit/:id" element={<EditArea />} />
            {/* CITY ROUTE */}
            <Route path="/city" element={<City />} />
            <Route path="/city/add" element={<AddCity />} />
            <Route path="/city/edit/:id" element={<EditCity />} />
            {/* COURSE ROUTE */}
            <Route path="/course" element={<Course />} />
            <Route path="/course/add" element={<AddCourse />} />
            <Route path="/course/edit/:id" element={<EditCourse />} />
            {/* USER ROUTE */}
            <Route path="/user" element={<User />} />
            <Route path="/user/add" element={<AddUser />} />
            {/* <Route path="/user/edit/:id" element={<EditUser />} /> */}
            {/* BANNER ROUTE */}
            <Route path="/banner" element={<Banner />} />
            <Route path="/banner/add" element={<AddBanner />} />
            <Route path="/banner/edit/:id" element={<EditBanner />} />
            {/* NOTIFICATION ROUTE */}
            <Route path="/notification" element={<PreviousNotification />} />
            <Route path="/notification/add" element={<Notification />} />
            <Route
              path="/notification/view/:id"
              element={<DetailNotification />}
            />
            {/* ADMIT CARD ROUTE */}
            <Route path="/admitcard" element={<AdmitCard />} />
            {/* EXAM ROUTE */}
            <Route path="/scheduleexam" element={<ScheduleExam />} />
            <Route path="/thankyou" element={<Thankyou />} />
            <Route path="/examtable" element={<ExamTable />} />
          </Routes>
        </Box>
      </Box>
    </>
  );
};

export default NavigationTab;
