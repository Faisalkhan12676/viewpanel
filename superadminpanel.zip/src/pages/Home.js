import { Label } from "@mui/icons-material";
import {
  Button,
  Checkbox,
  Container,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { border, Box, padding, style, width } from "@mui/system";
import { Formik, useFormik, Field, Form, FormikProps } from "formik";
import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import axios from "axios";
import { BASE_URL } from "../config";

// import Button from '@mui/material/Button';
// import Typography from '@mui/material/Typography';
import exportFromJSON from "export-from-json";
import { TailSpin } from "react-loader-spinner";
import { color } from "../components/colors";


const Home = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [count, setCount] = useState([]);
  const [isloading, setIsloading] = useState("EXPORT CSV");
  const [isloading2, setIsloading2] = useState(true);

  useEffect(() => {
    axios
      .get(`${BASE_URL}/Student/GetStudentCount`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((res) => {
        // console.log(res.data);
        setCount(res.data);
        setIsloading2(false);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const handleExport = () => {
    setIsloading("LOADING...");
    //hit api 7 times to get all data
    const total = count.totalUsers;
    const perPage = 1;
    axios
      .get(`${BASE_URL}/Student/ExportStudent?take=${total}&skip=${perPage}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((res) => {
        // console.log(res.data);
        setIsloading("EXPORT CSV");
        //remove createDate from data
        const data = res.data.map((item) => {
          delete item.createdDate;
          return item;
        }
        );
        // const data = res.data.filter((e)=> e.createdDate !== res.data.createdDate);
        console.log(data);
        const fileName = "AllStudents";
        const exportType = exportFromJSON.types.csv;
        exportFromJSON({ data, fileName, exportType });
      })
      .catch((err) => {
        console.log(err);
        setIsloading("EXPORT CSV");
      });
  };

  return (
    <>
      {isloading2 ? (
        <>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "80vh",
              
            }}
          >
            <TailSpin color={color.primary} />
          </div>
        </>
      ) : (
        <>
          <Button
            disabled={isloading === "LOADING..."}
            style={{
              margin: 10,
            }}
            variant="contained"
            onClick={handleExport}
          >
            {isloading}
          </Button>
          <Grid
            container
            spacing={{ xs: 2, md: 3 }}
            columns={{ xs: 12, sm: 12, md: 12 }}
          >
            <Grid item xs={12} md={3} sm={12}>
              <Card
                style={{
                  width: "100%",
                  width: "100%",
                  borderWidth: 1,
                  padding: 10,
                  borderColor: "#000",
                  borderWidth: 1,
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  flexDirection: "column",
                  margin: 10,
                }}
              >
                <h1>{count.totalUsers}</h1>
                <h3>Total Users</h3>
              </Card>
            </Grid>

            <Grid item xs={12} md={3} sm={12}>
              <Card
                style={{
                  width: "100%",
                  width: "100%",
                  borderWidth: 1,
                  padding: 10,
                  borderColor: "#000",
                  borderWidth: 1,
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  flexDirection: "column",
                  margin: 10,
                }}
              >
                <h1>{count.total}</h1>
                <h3>Total Registration</h3>
              </Card>
            </Grid>

            <Grid item xs={12} md={3} sm={12}>
              <Card
                style={{
                  width: "100%",
                  width: "100%",
                  borderWidth: 1,
                  padding: 10,
                  borderColor: "#000",
                  borderWidth: 1,
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  flexDirection: "column",
                  margin: 10,
                }}
              >
                <h1>{count.male}</h1>
                <h3>Males</h3>
              </Card>
            </Grid>
            <Grid item xs={12} md={3} sm={12}>
              <Card
                style={{
                  width: "100%",
                  width: "100%",
                  borderWidth: 1,
                  padding: 10,
                  borderColor: "#000",
                  borderWidth: 1,
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  flexDirection: "column",
                  margin: 10,
                }}
              >
                <h1>{count.female}</h1>
                <h3>Females</h3>
              </Card>
            </Grid>
          </Grid>
        </>
      )}
    </>
  );
};

export default Home;
