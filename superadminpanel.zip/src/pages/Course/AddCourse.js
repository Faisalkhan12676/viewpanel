import React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";
import { Formik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASE_URL } from "../../config";
import { useNavigate } from "react-router-dom";

const AddCourse = () => {
    const navigate = useNavigate();
  return (
    <div className="cardarea">
    <div className="cardinput">
      <Formik
        initialValues={{
          name: "",
          description: "",
        }}
        onSubmit={(values) => {
          axios
            .post(
              `${BASE_URL}/Course/Add`,
              {
                name: values.name,
                description: values.description,
              },
              {
                headers: {
                  Authorization: `Bearer ${sessionStorage.getItem(
                    "token"
                  )}`,
                },
              }
            )
            .then((res) => {
              // console.log(res);
              navigate("/dashboard/course");
            })
            .catch((err) => {
              console.log(err);
            });
        }}
        validationSchema={Yup.object({
          name: Yup.string().required("Name is required"),
            description: Yup.string().required("Description is required"),
        })}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
        }) => (
          <>
            <TextField
              id="name"
              label="Course Name"
              variant="outlined"
              margin="normal"
              required
              fullWidth
              helperText={touched.name && errors.name}
              error={touched.name && errors.name}
              onChange={handleChange("name")}
              onBlur={handleBlur("name")}
              value={values.name}
            />
            <TextField
                id="description"
                label="Description"
                variant="outlined"
                margin="normal"
                required
                multiline
                maxRows={15}
                fullWidth
                helperText={touched.description && errors.description}
                error={touched.description && errors.description}
                onChange={handleChange("description")}
                onBlur={handleBlur("description")}
                value={values.description}
                />

            <Button
              variant="contained"
              color="primary"
              onClick={() => handleSubmit()}
            >
              Add
            </Button>
          </>
        )}
      </Formik>
    </div>
  </div>
  )
}

export default AddCourse