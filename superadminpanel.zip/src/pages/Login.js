import { Button, Container, TextField, Typography } from "@mui/material";
import { Box } from "@mui/system";
import axios from "axios";
import { useFormik } from "formik";
import React, { useState,useEffect } from "react";
import { decodeToken, isExpired } from "react-jwt";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import * as Yup from "yup";
import { color } from "../components/colors";
import { BASE_URL } from "../config";
import img from '../components/fav.png'




const validate = Yup.object({
  username: Yup.string("Enter Your Username").required("Username is required"),

  password: Yup.string("Enter Your Password")
    
    .required("Password is required"),
});

const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [token, setToken] = useState("");
  const [role, setRole] = useState("");
  const [err, setErr] = useState("");
  const [disabled, setDisabled] = useState(false);

  

  const formik = useFormik({
    initialValues: {
      username: "",
      password: "",
    },
    validationSchema: validate,

    onSubmit: (values, action) => {
      action.resetForm();
      setDisabled(true);
      // console.log(values);
      axios
        .post(`${BASE_URL}/Auth/loginsuperadmin`, values)
        .then((res) => {
          // console.log(res);
          if(res.data.role === "SuperAdmin"){
            sessionStorage.setItem("role", res.data.role);
            sessionStorage.setItem("token", res.data.token);
            dispatch({ type: "LOGIN" });
            navigate("/dashboard/home");
            setDisabled(false);
          }else{
            navigate("/login");
            setDisabled(false);
          }

          
        })
        .catch((err) => {
          // console.log(err.response.data);
          setErr(err.response.data);
          setDisabled(false);
        });
    },
  });

  return (
    <>
      <Container
        maxWidth="xlg"
        sx={{
          bgcolor: "#cfe8fc",
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Box
          sx={{
            bgcolor: "#eee",
            height: "auto",
            width: "450px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
            padding: 5,
            borderRadius: 5,
          }}
        >
            <div style={{
          height: "150px",
          width: "150px",
        }} >
          <img style={{
            height: "100%",
            width: "100%",
            objectFit: "contain",
          }} src={img} />
        </div>
          <Typography variant="h5">Bano Qabil Super Admin Panel</Typography>
          <form>
            <TextField
              label="Username"
              variant="outlined"
              sx={{ width: "100%", marginY: 2 }}
              onBlur={formik.handleBlur("username")}
              onChange={formik.handleChange("username")}
              value={formik.values.username}
              error={formik.touched.username && Boolean(formik.errors.username)}
              helperText={formik.touched.username && formik.errors.username}
              disabled={disabled}
            />
            <TextField
              label="Password"
              variant="outlined"
              sx={{ width: "100%", marginY: 2 }}
              onBlur={formik.handleBlur("password")}
              onChange={formik.handleChange("password")}
              value={formik.values.password}
              error={(formik.touched.password && Boolean(formik.errors.password))}
              helperText={formik.touched.password && formik.errors.password}
              type="password"
              disabled={disabled}
            />
            <p style={{
              color: "red",
            }}>
              {err}
            </p>

            <Button disabled={disabled} style={{backgroundColor:color.primary}} variant="contained" onClick={() => formik.handleSubmit()}>
              Login
            </Button>
          </form>
        </Box>
      </Container>
    </>
  );
};

export default Login;
