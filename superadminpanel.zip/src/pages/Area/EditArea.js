import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";
import { Formik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASE_URL } from "../../config";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { useNavigate,useParams } from "react-router-dom";

const EditArea = () => {
  const [cities, setCities] = useState([]);
  const { id } = useParams();
  const [newdata,setNewData] = useState({});
  const navigate = useNavigate();
  useEffect(() => {
    axios.get(`${BASE_URL}/Area/GetByIdWithRelationShip?id=${id}`,{
      headers: {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      },
    }).then((res)=>{
      setNewData(res.data);
      // console.log(res.data);
    }).catch((err)=>{
      console.log(err);
    })


    axios
      .get(`${BASE_URL}/City/GetAll`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((res) => {
        setCities(res.data);
        // console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  return (
    <>
      <div className="cardarea">
        <div className="cardinput">
          <Formik
            initialValues={{
              name: "" || newdata.name,
              cityId: "" || newdata.cityId,
            }}
            enableReinitialize={true}
            onSubmit={(values) => {
              axios
                .put(
                  `${BASE_URL}/Area/Update?id=${id}`,
                  {
                    id:id,
                    name: values.name,
                    cityId: values.cityId,
                  },
                  {
                    headers: {
                      Authorization: `Bearer ${sessionStorage.getItem(
                        "token"
                      )}`,
                    },
                  }
                )
                .then((res) => {
                  // console.log(res);
                  navigate("/dashboard/area");
                })
                .catch((err) => {
                  console.log(err);
                });
            }}
            validationSchema={Yup.object({
              name: Yup.string().required("City Name is required"),
              cityId: Yup.string().required("City Name is required"),
            })}
          >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleBlur,
              handleSubmit,
            }) => (
              <>
                <InputLabel id="demo-select-small">Area</InputLabel>
                <TextField
                
                  id="name"
                  variant="outlined"
                  margin="normal"
                  required
                  fullWidth
                  helperText={touched.name && errors.name}
                  error={touched.name && errors.name}
                  onChange={handleChange("name")}
                  onBlur={handleBlur("name")}
                  value={values.name}
                  
                />
                <FormControl
                  style={{
                    width: "100%",
                  }}
                >
                  <InputLabel id="demo-select-small">{newdata.city}</InputLabel>
                  <Select
                    labelId="demo-select-small"
                    id="demo-select-small"
                    value={values.cityId}
                    label={newdata.city}
                    onChange={handleChange("cityId")}
                    error={touched.cityId && errors.cityId}
                    helperText={touched.cityId && errors.cityId}
                  >
                    <MenuItem value={newdata.city}>
                      <em>{newdata.city}</em>
                    </MenuItem>
                    {cities.map((city) => (
                      <MenuItem key={city.id} value={city.id}>
                        {city.name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>

                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleSubmit()}
                  style={{
                    marginTop: "10px",
                  }}
                >
                  Add
                </Button>
              </>
            )}
          </Formik>
        </div>
      </div>
    </>
  );
};

export default EditArea;
