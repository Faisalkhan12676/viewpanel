import React, { useEffect, useState } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Button } from "@mui/material";
import axios from "axios";
import { BASE_URL } from "../../config";
import { useNavigate, useParams } from "react-router-dom";
import { TailSpin } from "react-loader-spinner";
import { color } from "../../components/colors";

const DetailNotification = () => {
  const { id } = useParams();
  const [newdata, setNewData] = useState({});
  const navigate = useNavigate();
  const [isloading2, setIsloading2] = useState(false);
  const getAllStudents = () => {
    axios
      .get(`${BASE_URL}/Notification/GetById?id=${id}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((res) => {
        setNewData(res.data);
      })
      .catch((err) => {
        // console.log(err);
      });
  };
  useEffect(() => {
    getAllStudents();
  }, []);
  return (
    <>
      {isloading2 ? (
        <>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "80vh",
            }}
          >
            <TailSpin color={color.primary} />
          </div>
        </>
      ) : (
        <>
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>Student Reg</TableCell>
                  <TableCell>SMS</TableCell>
                  <TableCell>EMAIL</TableCell>
                  <TableCell>Web</TableCell>
                  <TableCell>App</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell>Student001</TableCell>
                  <TableCell>{newdata.sms === 1 ? "Y" : "N"}</TableCell>
                  <TableCell>{newdata.email === 1 ? "Y" : "N"}</TableCell>
                  <TableCell>{newdata.web === 1 ? "Y" : "N"}</TableCell>
                  <TableCell>{newdata.app === 1 ? "Y" : "N"}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </>
      )}
    </>
  );
};

export default DetailNotification;
