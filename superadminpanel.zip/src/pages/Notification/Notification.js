import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";
import { Formik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASE_URL } from "../../config";
import { useNavigate } from "react-router-dom";
import Checkbox from "@mui/material/Checkbox";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
// import Box from '@mui/material/Box';
import LinearProgress from "@mui/material/LinearProgress";
import { useDispatch } from "react-redux";
import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";
import CheckIcon from "@mui/icons-material/Check";

const Notification = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [isloading, setisloading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [count, setCount] = useState([]);
  const [isDisabled, setisDisabled] = useState(false);
  const [open, setOpen] = React.useState(false);
  useEffect(() => {
    axios
      .get(`${BASE_URL}/Student/GetStudentCount`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((res) => {
        // console.log(res.data);
        setCount(res.data);
      })
      .catch((err) => {
        // console.log(err);
      }); 
  }, []);

  // const std = [10509, 10510];

  const getAllStudents = (id) => {
    // setOpen(true);
    //hit api after 5 seconds
    // setisloading(false);
    // setisloading(true);

    axios
      .post(
        `${BASE_URL}/Notification_log/Add`,
        {
          notificationId: id,
          studentId: null,
        },
        {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          },
        }
      )
      .then((res) => {
        // console.log(res);
        // console.log("Hitted", i);
        setOpen(!open);
        setisloading(true);
        setOpen(true);
        setTimeout(() => {
          dispatch({ type: "LOGOUT" });
          sessionStorage.clear();
          window.location.reload(true);
        }, 5000);
      })
      .catch((err) => {
        // console.log(err);
        // console.log("Hitted" + i);
        //setopen false when condition is false

        setOpen(false);
        setisloading(false);
      });
  };

  return (
    <div className="cardarea">
      <div className="cardinput">
        <h1>Create Notification</h1>
        {isloading ? (
          <>
            <Backdrop
              sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
              open={open}
            >
              <h1>Sending Notifications</h1>
            </Backdrop>
            <Formik
              initialValues={{
                notificationMsg: "",
                email: "email",
                sms: "",
                web: "web",
                app: "app",
              }}
              onSubmit={(values) => {
                // console.log(values);
                axios
                  .post(
                    `${BASE_URL}/Notification/Add`,
                    {
                      notificationMsg: values.notificationMsg,
                      email: values.email,
                      // sms: values.sms,
                      web: values.web,
                      app: values.app,
                    },
                    {
                      headers: {
                        Authorization: `Bearer ${sessionStorage.getItem(
                          "token"
                        )}`,
                      },
                    }
                  )
                  .then((res) => {
                    // console.log(res);
                    // navigate("/dashboard/notification");
                    // setisloading(true);
                    console.log(res.data);
                    const { id } = res.data;
                    getAllStudents(id);
                  })
                  .catch((err) => {
                    // console.log(err);
                  });
              }}
              validationSchema={Yup.object({
                notificationMsg: Yup.string().required(
                  "Notification is required"
                ),
                // email: Yup.string().required("Email is required"),
                // sms: Yup.string().required("SMS is required"),
                // web: Yup.string().required("Web is required"),
                // app: Yup.string().required("App is required"),
              })}
            >
              {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                handleSubmit,
                setFieldValue,
              }) => (
                <>
                  <Box
                    m={2}
                    sx={{
                      width: "100%",
                    }}
                  >
                    <TextField
                      id="notificationMsg"
                      label="Notification"
                      variant="outlined"
                      margin="normal"
                      onChange={handleChange("notificationMsg")}
                      onBlur={handleBlur("notificationMsg")}
                      value={values.notificationMsg}
                      style={{
                        width: "100%",
                      }}
                      helperText={
                        errors.notificationMsg && touched.notificationMsg
                      }
                      error={errors.notificationMsg && touched.notificationMsg}
                    />
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        marginTop: "10px",
                      }}
                    >
                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Checkbox
                              aria-label="checkbox"
                              checked={values.email === "email" ? true : false}
                              onChange={() => {
                                if (values.email === "") {
                                  setFieldValue("email", "email");
                                } else {
                                  setFieldValue("email", "");
                                }
                              }}
                              name="email"
                              value="email"
                            />
                          }
                          label="Email"
                        />
                        <FormControlLabel
                          control={
                            <Checkbox
                              disabled
                              aria-label="checkbox"
                              checked={values.sms === "" ? true : false}
                              onChange={() => {
                                if (values.sms === "") {
                                  setFieldValue("sms", "");
                                } else {
                                  setFieldValue("sms", "");
                                }
                              }}
                              name="sms"
                              value="sms"
                            />
                          }
                          label="SMS"
                        />
                      </FormGroup>

                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Checkbox
                              aria-label="checkbox"
                              checked={values.web === "web" ? true : false}
                              onChange={() => {
                                if (values.web === "") {
                                  setFieldValue("web", "web");
                                } else {
                                  setFieldValue("web", "");
                                }
                              }}
                              name="web"
                              value="web"
                            />
                          }
                          label="Web"
                        />

                        <FormControlLabel
                          control={
                            <Checkbox
                              aria-label="checkbox"
                              checked={values.app === "app" ? true : false}
                              onChange={() => {
                                if (values.app === "") {
                                  setFieldValue("app", "app");
                                } else {
                                  setFieldValue("app", "");
                                }
                              }}
                              name="app"
                              value="app"
                            />
                          }
                          label="App"
                        />
                      </FormGroup>
                    </div>

                    <Button
                      startIcon={isloading ? <CheckIcon /> : <></>}
                      variant="contained"
                      onClick={() => handleSubmit()}
                      style={{
                        marginTop: "10px",
                        width: "100%",
                        backgroundColor: isloading ? "green" : "#015AAB",
                      }}
                      disabled={
                        values.email === "" &&
                        values.sms === "" &&
                        values.web === "" &&
                        values.app === ""
                          ? true
                          : false
                      }
                    >
                      Send
                    </Button>
                  </Box>
                </>
              )}
            </Formik>
          </>
        ) : (
          <>
            <Formik
              initialValues={{
                notificationMsg: "",
                email: "email",
                sms: "",
                web: "web",
                app: "app",
              }}
              onSubmit={(values) => {
                // console.log(values);
                setisDisabled(true);
                axios
                  .post(
                    `${BASE_URL}/Notification/Add`,
                    {
                      notificationMsg: values.notificationMsg,
                      email: values.email,
                      // sms: values.sms,
                      web: values.web,
                      app: values.app,
                    },
                    {
                      headers: {
                        Authorization: `Bearer ${sessionStorage.getItem(
                          "token"
                        )}`,
                      },
                    }
                  )
                  .then((res) => {
                    // console.log(res);
                    // navigate("/dashboard/notification");
                    // setisloading(true);
                    console.log(res.data);
                    const { id } = res.data;
                    getAllStudents(id);
                  })
                  .catch((err) => {
                    // console.log(err);
                  });
              }}
              validationSchema={Yup.object({
                notificationMsg: Yup.string().required(
                  "Notification is required"
                ),
                // email: Yup.string().required("Email is required"),
                // sms: Yup.string().required("SMS is required"),
                // web: Yup.string().required("Web is required"),
                // app: Yup.string().required("App is required"),
              })}
            >
              {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                handleSubmit,
                setFieldValue,
              }) => (
                <>
                  <Box
                    m={2}
                    sx={{
                      width: "100%",
                    }}
                  >
                    <TextField
                      id="notificationMsg"
                      label="Notification"
                      variant="outlined"
                      margin="normal"
                      onChange={handleChange("notificationMsg")}
                      onBlur={handleBlur("notificationMsg")}
                      value={values.notificationMsg}
                      style={{
                        width: "100%",
                      }}
                      helperText={
                        errors.notificationMsg && touched.notificationMsg
                      }
                      error={errors.notificationMsg && touched.notificationMsg}
                    />
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        marginTop: "10px",
                      }}
                    >
                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Checkbox
                              aria-label="checkbox"
                              checked={values.email === "email" ? true : false}
                              onChange={() => {
                                if (values.email === "") {
                                  setFieldValue("email", "email");
                                } else {
                                  setFieldValue("email", "");
                                }
                              }}
                              name="email"
                              value="email"
                            />
                          }
                          label="Email"
                        />
                        <FormControlLabel
                          control={
                            <Checkbox
                              disabled
                              aria-label="checkbox"
                              checked={values.sms === "" ? true : false}
                              onChange={() => {
                                if (values.sms === "") {
                                  setFieldValue("sms", "");
                                } else {
                                  setFieldValue("sms", "");
                                }
                              }}
                              name="sms"
                              value="sms"
                            />
                          }
                          label="SMS"
                        />
                      </FormGroup>

                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Checkbox
                              aria-label="checkbox"
                              checked={values.web === "web" ? true : false}
                              onChange={() => {
                                if (values.web === "") {
                                  setFieldValue("web", "web");
                                } else {
                                  setFieldValue("web", "");
                                }
                              }}
                              name="web"
                              value="web"
                            />
                          }
                          label="Web"
                        />

                        <FormControlLabel
                          control={
                            <Checkbox
                              aria-label="checkbox"
                              checked={values.app === "app" ? true : false}
                              onChange={() => {
                                if (values.app === "") {
                                  setFieldValue("app", "app");
                                } else {
                                  setFieldValue("app", "");
                                }
                              }}
                              name="app"
                              value="app"
                            />
                          }
                          label="App"
                        />
                      </FormGroup>
                    </div>

                    <Button
                      startIcon={isloading ? <CheckIcon /> : <></>}
                      variant="contained"
                      
                      onClick={() => handleSubmit()}
                      style={{
                        marginTop: "10px",
                        width: "100%",
                        backgroundColor: isloading ? "green" : "#015AAB",
                        color: isDisabled ? "white" : "white",
                      }}
                      disabled={isDisabled ? true : false}
                    >
                      {isDisabled ? "Loading..." : "Send"}
                    </Button>
                  </Box>
                </>
              )}
            </Formik>
          </>
        )}
      </div>
    </div>
  );
};

export default Notification;
