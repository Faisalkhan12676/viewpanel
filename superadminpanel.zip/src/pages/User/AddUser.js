import React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";
import { Formik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASE_URL } from "../../config";
import { useNavigate } from "react-router-dom";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

const AddUser = () => {
  const navigate = useNavigate();
  return (
    <div className="cardarea">
      <div className="cardinput">
        <Formik
          initialValues={{
            name: "",
            username: "",
            email: "",
            role: "",
            password: "",
          }}
          onSubmit={(values) => {
            axios
              .post(
                `${BASE_URL}/Auth/AdminRegister`,
                {
                  name: values.name,
                  username: values.username,
                  email: values.email,
                  password: values.password,  
                  role: values.role,
                },
                {
                  headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                  },
                }
              )
              .then((res) => {
                // console.log(res);
                navigate("/dashboard/user");
              })
              .catch((err) => {
                console.log(err);
              });
          }}
          validationSchema={Yup.object({
            name: Yup.string().required("Name is required"),
            username: Yup.string().required("Username is required"),
            email: Yup.string().required("Email is required"),
            role: Yup.string().required("Role is required"),
            password: Yup.string().required("Password is required"),
          })}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
          }) => (
            <>
              <TextField
                id="name"
                label="name"
                variant="outlined"
                margin="normal"
                required
                fullWidth
                helperText={touched.name && errors.name}
                error={touched.name && errors.name}
                onChange={handleChange("name")}
                onBlur={handleBlur("name")}
                value={values.name}
              />
              <TextField
                id="username"
                label="username"
                variant="outlined"
                margin="normal"
                required
                fullWidth
                helperText={touched.username && errors.username}
                error={touched.username && errors.username}
                onChange={handleChange("username")}
                onBlur={handleBlur("username")}
                value={values.username}
              />
              <TextField
                id="email"
                label="email"
                variant="outlined"
                margin="normal"
                required
                fullWidth
                helperText={touched.email && errors.email}
                error={touched.email && errors.email}
                onChange={handleChange("email")}
                onBlur={handleBlur("email")}
                value={values.email}
              />

              <TextField
                id="password"
                label="password"
                variant="outlined"
                margin="normal"
                required
                fullWidth
                helperText={touched.password && errors.password}
                error={touched.password && errors.password}
                onChange={handleChange("password")}
                onBlur={handleBlur("password")}
                value={values.password}
              />

              <FormControl variant="outlined" margin="normal" fullWidth>
                <InputLabel id="demo-simple-select-label">Roles</InputLabel>
                <Select
                  id="role"
                  label="role"
                  variant="outlined"
                  margin="normal"
                  required
                  fullWidth
                  helperText={touched.role && errors.role}
                  error={touched.role && errors.role}
                  onChange={handleChange("role")}
                  onBlur={handleBlur("role")}
                  value={values.role}
                >
                  <MenuItem value="Admin">Admin</MenuItem>
                  <MenuItem value="Manager">View</MenuItem>
                  <MenuItem value="SuperAdmin">Super Admin</MenuItem>
                </Select>
              </FormControl>

              <Button
                variant="contained"
                color="primary"
                style={{ marginTop: "20px" }}
                onClick={() => handleSubmit()}
              >
                Add
              </Button>
            </>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default AddUser;
