import React from 'react'

const EditUser = () => {
  return (
    <div>EditUser</div>
  )
}

export default EditUser