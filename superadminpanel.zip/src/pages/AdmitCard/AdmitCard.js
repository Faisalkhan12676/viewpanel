import { Button, TextField } from "@mui/material";
import React, { useEffect, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import axios from "axios";
import { BASE_URL } from "../../config";
import QRCode from "react-qr-code";

const AdmitCard = () => {
  const [admitcard, setAdmitcard] = useState({});
  const [id, setId] = useState(null);
  const [isloading, setIsloading] = useState(true);
  const [img, setImg] = useState("");
  const [msg, setMsg] = useState("Search by ID");

  const getData = () => {
    setMsg("Loading...");
    setIsloading(true);
    axios
      .get(`${BASE_URL}/Student/AdmitCard?id=${id}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((res) => {
        if (res.status === 200) {
          setAdmitcard(res.data);
          console.log(res.data);
          setIsloading(false);
        }
      })
      .catch((err) => {
        if (err.response.status === 400 || err.response.status === 500) {
          setIsloading(true);
          setMsg("Not Found");
        }
      });
  };
  const getImage = () => {
    axios
      .get(`${BASE_URL}/Student/GetAdmitCardImage?id=${id}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((res) => {
        console.log(res.data);
        setImg(res.data);
        setIsloading(false);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handlesearched = () => {
    getData();
    getImage();
  };

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          height: "auto",
          width: "100%",
        }}
      >
        <div
         className="inputs"
        >
          <TextField
            style={{
              width: "100%",
            }}
            id="outlined-basic"
            label="Search"
            variant="outlined"
            onChange={(e) => setId(e.target.value)}
          />
          <Button
            style={{
              marginLeft: "10px",
            }}
            color="primary"
            variant="contained"
            onClick={handlesearched}
          >
            <SearchIcon />
          </Button>
        </div>
      </div>

      {isloading ? (
        <>
            <div style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "80vh",
                width: "100%",
            }}>
                <h1 style={{color:"#ced4da"}}>{msg}</h1>
            </div>
        </>
      ) : (
        <>
          <div className="card" >
            <div
              style={{
                height: "150px",
                width: "150px",
                borderRadius: "50%",
                marginTop: "20px",
              }}
            >
              <img
                src={img.image}
                style={{
                  height: "100%",
                  width: "100%",
                  borderRadius: "50%",
                  objectFit: "cover",
                }}
              />
            </div>

            <div
              style={{
                backgroundColor: "#eee",
                height: "100%",
                width: "80%",
                display: "flex",
                justifyContent: "space-between",
              }}
            >
              <p>Registration No.</p>
              <p>{admitcard.user.username + admitcard.user.id}</p>
            </div>

            <div
              style={{
                backgroundColor: "#eee",
                height: "100%",
                width: "80%",
                display: "flex",
                justifyContent: "space-between",
              }}
            >
              <p>Name</p>
              <p>{admitcard.user.name}</p>
            </div>

            <div
              style={{
                backgroundColor: "#eee",
                height: "100%",
                width: "80%",
                display: "flex",
                justifyContent: "space-between",
              }}
            >
              <p>Father Name</p>
              <p>{admitcard.student.fatherName}</p>
            </div>

            <div
              style={{
                backgroundColor: "#eee",
                height: "100%",
                width: "80%",
                display: "flex",
                justifyContent: "space-between",
              }}
            >
              <p>Phone</p>
              <p>{admitcard.user.email}</p>
            </div>

            <div
              style={{
                backgroundColor: "#eee",
                height: "100%",
                width: "80%",
                display: "flex",
                justifyContent: "center",
                marginBottom: "20px",
              }}
            >
              <QRCode
                size={120}
                value={
                  "NAME" +
                  ": " +
                  admitcard.user.name +
                  "\n" +
                  "FATHER NAME" +
                  ": " +
                  admitcard.student.fatherName +
                  "\n" +
                  "REGISTRATION NO" +
                  ": " +
                  admitcard.user.username +
                  admitcard.user.id +
                  "\n" +
                  "PHONE" +
                  ": " +
                  admitcard.user.email
                }
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AdmitCard;
