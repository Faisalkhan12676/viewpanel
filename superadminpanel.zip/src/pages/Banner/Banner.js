import React, { useEffect, useState } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Button } from "@mui/material";
import axios from "axios";
import { BASE_URL } from "../../config";
import { Link, useNavigate } from "react-router-dom";
import { TailSpin } from "react-loader-spinner";
import { color } from "../../components/colors";

const Banner = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const getBanner = () => {
    axios
      .get(`${BASE_URL}/BannerImage/GetAll`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((res) => {
        setData(res.data);
        setLoading(false);
        // console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    getBanner();
  }, []);

  return (
    <>
      {loading ? (
        <>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "80vh",
            }}
          >
            <TailSpin color={color.primary} />
          </div>
        </>
      ) : (
        <>
          <Button
            variant="contained"
            style={{
              margin: 10,
            }}
            onClick={() => navigate("/dashboard/banner/add")}
          >
            ADD
          </Button>

          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell align="center">BANNER</TableCell>
                  <TableCell>ACTIONS</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.map((item, index) => (
                  <>
                    <TableRow key={index}>
                      <TableCell component="th" scope="row">
                        {item.id}
                      </TableCell>
                      <TableCell align="center">
                        <img
                          src={item.image}
                          alt="banner"
                          width="200px"
                          height="100px"
                          style={{
                            objectFit: "contain",
                          }}
                        />
                      </TableCell>
                      <TableCell align="center">
                        <Button
                          style={{
                            color: "#00bcd4",
                          }}
                          onClick={() =>
                            navigate(`/dashboard/banner/edit/${item.id}`)
                          }
                        >
                          Edit
                        </Button>
                        <Button
                          style={{
                            color: "red",
                          }}
                          onClick={() => {
                            axios
                              .delete(`${BASE_URL}/BannerImage/Remove?id=${item.id}`, {
                                headers: {
                                  Authorization: `Bearer ${sessionStorage.getItem(
                                    "token"
                                  )}`,
                                },
                              })
                              .then((res) => {
                                getBanner();
                              })
                              .catch((err) => {
                                console.log(err);
                              });
                          }}
                        >
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  </>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      )}
    </>
  );
};

export default Banner;
