import React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";
import { Formik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASE_URL } from "../../config";
import { useNavigate } from "react-router-dom";

const AddBanner = () => {
  const navigate = useNavigate();
  return (
    <div className="cardarea">
      <div className="cardinput">
        <Formik
          initialValues={{
            image: "",
            ext: "",
          }}
          onSubmit={(values) => {
            axios
              .post(
                `${BASE_URL}/BannerImage/Add`,
                {
                  image: values.image.split(',')[1],
                  ext: values.ext,
                },
                {
                  headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                  },
                }
              )
              .then((res) => {
                console.log(res);
              })
              .catch((err) => {
                console.log(err);
              });
          }}
          validationSchema={Yup.object({
            image: Yup.string().required("Image is required"),
            ext: Yup.string().required("Extension is required"),
          })}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
            setFieldValue,
          }) => (
            <>
              <TextField
                id="outlined-basic"
                type="file"
                label="Select Image"
                variant="standard"
                helperText={errors.image && touched.image && errors.image}
                error={errors.image && touched.image}
                onChange={async (e) => {
                  //check size of banner
                  const file = e.target.files[0];
                  const size = file.size;
                  if (size > 5000000) {
                    alert("Image size should be less than 5MB");
                    return;
                  }
                  //check extension of banner
                  const ext = file.name.split(".").pop();
                  if (ext !== "jpg" && ext !== "png" && ext !== "jpeg") {
                    alert("Image extension should be jpg, png or jpeg");
                    return;
                  }

                  //base64
                  const reader = new FileReader();
                  reader.readAsDataURL(file);
                  reader.onload = (e) => {
                    setFieldValue("image", e.target.result);
                    setFieldValue("ext", ext);
                  };
                  reader.onerror = (error) => {
                    console.log("Error: ", error);
                  };
                }}
              />
              <Button
                variant="contained"
                color="primary"
                onClick={handleSubmit}
                style={{ marginTop: "10px" }}
              >
                Add
              </Button>
            </>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default AddBanner;
