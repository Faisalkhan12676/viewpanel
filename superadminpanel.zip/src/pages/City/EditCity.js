import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";
import { Formik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASE_URL } from "../../config";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { useNavigate,useParams } from "react-router-dom";


const EditCity = () => {
  const { id } = useParams();
  const [newdata,setNewData] = useState({});
  const navigate = useNavigate();
  useEffect(() => {
    axios.get(`${BASE_URL}/City/GetById?id=${id}`,{
      headers: {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      },
    }).then((res)=>{
      setNewData(res.data);
      // console.log(res.data);
    }).catch((err)=>{
      console.log(err);
    });
  }, []);
  return (
    <div className="cardarea">
    <div className="cardinput">
      <Formik
        initialValues={{
          name: "" || newdata.name,
        }}
        enableReinitialize={true}
        onSubmit={(values) => {
          axios
            .put(
              `${BASE_URL}/City/Update?id=${id}`,
              {
                id:id,
                name: values.name,
              },
              {
                headers: {
                  Authorization: `Bearer ${sessionStorage.getItem(
                    "token"
                  )}`,
                },
              }
            )
            .then((res) => {
              // console.log(res);
              navigate("/dashboard/city");
            })
            .catch((err) => {
              console.log(err);
            });
        }}
        validationSchema={Yup.object({
          name: Yup.string().required("Name is required"),
        })}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
        }) => (
          <>
            <TextField
              id="name"
              
              variant="outlined"
              margin="normal"
              required
              fullWidth
              helperText={touched.name && errors.name}
              error={touched.name && errors.name}
              onChange={handleChange("name")}
              onBlur={handleBlur("name")}
              value={values.name}
            />
            <Button
              variant="contained"
              color="primary"
              onClick={() => handleSubmit()}
            >
              Add
            </Button>
          </>
        )}
      </Formik>
    </div>
  </div>
  )
}

export default EditCity