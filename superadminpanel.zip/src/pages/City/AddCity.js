import React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";
import { Formik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASE_URL } from "../../config";
import { useNavigate } from "react-router-dom";

const AddCity = () => {
  const navigate = useNavigate();
  return (
    <div className="cardarea">
        <div className="cardinput">
          <Formik
            initialValues={{
              name: "",
            }}
            onSubmit={(values) => {
              axios
                .post(
                  `${BASE_URL}/City/Add`,
                  {
                    name: values.name,
                  },
                  {
                    headers: {
                      Authorization: `Bearer ${sessionStorage.getItem(
                        "token"
                      )}`,
                    },
                  }
                )
                .then((res) => {
                  // console.log(res);
                  navigate("/dashboard/city");
                })
                .catch((err) => {
                  console.log(err);
                });
            }}
            validationSchema={Yup.object({
              name: Yup.string().required("Name is required"),
            })}
          >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleBlur,
              handleSubmit,
            }) => (
              <>
                <TextField
                  id="name"
                  label="City Name"
                  variant="outlined"
                  margin="normal"
                  required
                  fullWidth
                  helperText={touched.name && errors.name}
                  error={touched.name && errors.name}
                  onChange={handleChange("name")}
                  onBlur={handleBlur("name")}
                  value={values.name}
                />
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleSubmit()}
                >
                  Add
                </Button>
              </>
            )}
          </Formik>
        </div>
      </div>
  )
}

export default AddCity